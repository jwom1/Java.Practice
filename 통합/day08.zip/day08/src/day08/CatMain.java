package day08;

public class CatMain {
	
	
	public static void main(String[] args) {

		Cat c1 = new Cat("호두", 5, "스코티쉬 폴드", "회색");
		
		Cat c2 = new Cat("봄이", 6,"치즈","노란색");
		
		c2.name = "봄이";
		c2.age = 6;
		c2.kind = "치즈";
		c2.color = "노란색";
		
		c1.showCatInfo(); //*100번지 showCatInfo 해주세요.
		c2.showCatInfo();

	}

}
