package day07;

public class Human {
	//구조체는 내부에 저장할 변수만을 정의해둔 집합입니다.(구조체가 더 상위)
	//사람이 가진 요소 중, 프로그래밍적으로 표현하기위해
	//이름, 나이, 키만 저장할 수 있도록 하겠습니다.
	
	//지금 시점에서는 모든 변수 왼쪽에 public을 추가로 찍습니다.
	public String name;
	public int age;		
	public int height;
}
