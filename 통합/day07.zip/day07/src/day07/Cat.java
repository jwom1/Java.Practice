package day07;

public class Cat {

	public String name;
	public int age;
	public String color;
	public String like;
	
}
