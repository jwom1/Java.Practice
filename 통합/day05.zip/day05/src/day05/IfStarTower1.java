package day05;

public class IfStarTower1 {

	public static void main(String[] args) {

	}

}
