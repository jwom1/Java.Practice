package day05;

import java.util.Scanner;

public class BaekJoonTai {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
				
				int year = scan.nextInt();
				
				System.out.println(year+543);
				
				scan.close();
	}
}
