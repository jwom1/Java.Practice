package poly.instanceof_;

public class Student extends Human{

	// void 파라미터로 요청받지 않는 생성자만 정의해주세요.
	public Student(String name, int age) {
		super(name,age);
	}
	
	
}
