package poly.inheri;

public class Rat extends Monster{

	public Rat() {
		super("쥐",5,1,0,80);
	}
}
