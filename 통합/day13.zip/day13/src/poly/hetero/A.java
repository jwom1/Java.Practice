package poly.hetero;

public class A {

}
