package poly.casting;

public class Child2 extends Parent {

	@Override
	public void method2() {
		System.out.println("2번 자식의 2번 메서드");
		
	}
	public void method3() {
		System.out.println("2번 자식의 3번메서드");
	}
}
