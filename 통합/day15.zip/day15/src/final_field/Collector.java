package final_field;

public class Collector {

	// 참조형 변수를 가진 배열의 경우 배열자체의 주소는 final이지만
	// 배열 내부자료까지 바뀌지 않음을 보장하지 않습니다.
	final String[] stickers = {"피카츄", "꼬부기", "미뇽"};
	
	
}
