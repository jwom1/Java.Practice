package final_class_;

public class Parent {

}
