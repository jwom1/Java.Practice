package final_class_;

public class Child { //extends Parent {

	
}
