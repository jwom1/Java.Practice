package final_method;

public class Parent {

	public void method1() {}
	public final void method2() {} //상속 시 오버라이딩 불가
}
