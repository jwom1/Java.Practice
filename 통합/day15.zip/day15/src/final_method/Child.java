package final_method;

public class Child extends Parent {
	
	@Override
	public void method1() {
		//자식쪽 오버라이딩 허용
	}
	
	//@Override
	//public void method2() {
		//final은 재정의 불가}
}
