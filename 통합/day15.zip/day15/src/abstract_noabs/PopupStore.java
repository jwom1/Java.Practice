package abstract_noabs;

public class PopupStore {

	public void orderApple() {
		System.out.println("착즙 사과주스를 내줍니다. 가격은 못 정했습니다.");
	}
	public void orderOrange() {
		System.out.println("착즙 오렌지주스를 내줍니다. 가격은 못 정했습니다.");
	}
	public void orderGrape() {
		System.out.println("착즙 포도주스를 내줍니다. 가격은 못 정했습니다.");
	}
}

