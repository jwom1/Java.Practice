package has_a;

public class Police {

}
