package has_a;

public class Gun {

}
