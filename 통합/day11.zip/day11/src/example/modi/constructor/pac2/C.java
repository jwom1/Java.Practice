package example.modi.constructor.pac2;

import example.modi.constructor.pac1.A;

public class C {
	// 여러분들이 A를 호출해보세요.
	
	// public 생성자
	A a1 = new A(true);
	// default 생성자
	//A a2 = new A(44);
	// private 생성자
	//A a3 = new A("why?");
	
}
