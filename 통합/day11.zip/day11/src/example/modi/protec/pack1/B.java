package example.modi.protec.pack1;

public class B {

	public B() {
		A a = new A();
		a.s = "hi";
		a.method();
	}
	
}
