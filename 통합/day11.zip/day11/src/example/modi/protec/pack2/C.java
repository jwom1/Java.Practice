package example.modi.protec.pack2;

//import 패키지 구조 protec인지 꼭 확인!
import example.modi.protec.pack1.A;

public class C {

	public C() {
		//A.a = new A();
		//a.s = "huhuhu";
		//a.method();
		
	}
}
