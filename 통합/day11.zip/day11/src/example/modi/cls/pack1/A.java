package example.modi.cls.pack1;


/*
 *  default(package friendly) 제한자는 접근제한자를 생햑하면
 *  자동으로 간주됩니다. 같은 패키지 내부 자료들끼리만 접근가능합니다.
 */
class A {

	
}
