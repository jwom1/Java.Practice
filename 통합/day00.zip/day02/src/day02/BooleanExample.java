package day02;

public class BooleanExample {

	public static void main(String[] args) {
		// 논리형 타입(true/false)
		
		boolean b1 = true;
		boolean b2 = false;
		
		//boolean b3 = 0;(x)
		
		System.out.println(b1);
		System.out.println(b2);

	}

}
