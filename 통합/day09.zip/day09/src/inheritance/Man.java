package inheritance;

public class Man extends Human{

	public int height;
	public int weight;
	
}
