package inheritance;

public class SalaryMan extends Human {

	public int salary;
	
}
