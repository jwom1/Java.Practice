package inheritance;

public class Student extends Human {
	
	public String major;
	
}
