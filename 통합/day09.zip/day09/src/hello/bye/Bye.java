package hello.bye;

public class Bye {

}
