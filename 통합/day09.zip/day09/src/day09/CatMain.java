package day09;

public class CatMain {

	public static void main(String[] args) {
		// 다른 프로젝트의 클래스파일은 가져다 쓸 수 없다.
		//Cat cat = new Cat();
		
		
	}

}
