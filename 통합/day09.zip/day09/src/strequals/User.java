package strequals;

public class User {
	String id;
	String pw;
	
	// 생성자
	public User(String upw) {
		pw = upw;
	}
}
