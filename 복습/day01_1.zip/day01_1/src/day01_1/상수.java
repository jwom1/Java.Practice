package day01_1;

public class 상수 {
public static void main(String[] args) {
	int money = 10000;
	int salary = 400000;
	
	System.out.println(money+salary);

}
}
