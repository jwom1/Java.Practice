package day01_1;

public class 대문자소문자 {

	public static void main(String[] args) {
		//자바의 식별자 이름은 대문자 소문자를 구분
		int age = 20;
		int Age = 30;
				
		System.out.println(age);
		System.out.println(Age);
		
		/*식별자의 이름은 숫자로 시작 불가
		int 9number (x) */
		int number9 = 9;
		/* 식별자의 이름은 공백 불가
		int birth day (x)
		 */
		int birthday = 1101;
		
		System.out.println(number9 + birthday);
		
	}
}
