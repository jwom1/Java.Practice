package day01_1;

public class 복습2코멘트연습 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("저녁은 맥도날드"
				);
	}

}
