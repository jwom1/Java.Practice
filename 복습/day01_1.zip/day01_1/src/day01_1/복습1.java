package day01_1;
/**
 * 이건 배포자나 그...출처 등등을 표시하기 위한 주석이다.
 * 
 * @author 이건 배포자
 * @version 이건 버전 표시
 * 나머지 하나가 뭐지 기억이 안나네
 *
 */
public class 복습1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		//한 줄 주석은 닫는거 필요가 없음 // 중복도 가능
		/* 여러줄 주석은 닫는게 필요하다 중복도 불가능 */ 
	}

}
