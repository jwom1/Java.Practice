package day04_1;

public class EnhancedFor {
	public static void main(String[] args) {
	
		String[] bab = {"참치","치즈","어묵"};
		
		for(String kim : bab ) {
			System.out.println(kim+"김밥");
		}
}
}
