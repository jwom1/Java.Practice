package day04_1;

public class StringInt_1 {
	public static void main(String[] args) {
	
		String str = "30";
		
		int age = Integer.parseInt(str);
				
				System.out.println(age+1);
				System.out.println(str+1);
}
}
