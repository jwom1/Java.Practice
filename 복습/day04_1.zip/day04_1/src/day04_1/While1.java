package day04_1;

public class While1 {

	public static void main(String[] args) {
		
		int count = 5;
		
		while(count>3) {
			count--;
			System.out.println("while실행중"+count);
		}

	}

}
