package day04_1;

public class IfElseExample_1 {

	public static void main(String[] args) {
		//음수가 나오면 음수입니다, 양수가 나오면 홀수양수입니다/짝수양수입니다, 0이 나오면 0입니다.

		int a = 27;
		
		if(a<0){
			System.out.println("음수입니다.");
		}else if(a ==0){
			System.out.println("0입니다.");
		}else if(a>0 && a%2==0) {
			System.out.println("짝수 양수입니다.");
		}else if(a>0 && a%2!=0) {
			System.out.println("홀수 양수입니다.");
		}
	}

}
