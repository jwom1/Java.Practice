package day04_1;

import java.util.Scanner;

public class While2 {
	public static void main(String[] args) {
	
		Scanner scan = new Scanner(System.in);
		
		int com = (int)(Math.random()*9)+1;
		
		System.out.println("숫자를 입력해주세요.");
		int user = scan.nextInt();
		
		while(com!=user) {
			if(com<user) {
				System.out.println("값을 내려주세요.");
			}else {
				System.out.println("값을 올려주세요.");
			}
			
			System.out.println("값을 다시 입력해주세요.");
			user = scan.nextInt();
		}
		
}
}
