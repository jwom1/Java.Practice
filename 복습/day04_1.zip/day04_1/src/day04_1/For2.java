package day04_1;

public class For2 {
	public static void main(String[] args) {
		
		for(int i=0; i<101; i++) {
			if(i%7==0 && i!=0) {
				System.out.println(i);
			}
		}
		
		for(int i=7; i<101; i+=7) {
			System.out.println(i);
		}
	}
}
