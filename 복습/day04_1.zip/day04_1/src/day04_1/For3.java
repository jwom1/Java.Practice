package day04_1;

public class For3 {
	public static void main(String[] args) {
		
		int a = (int)(Math.random()*9)+1; // 범위가 1~9인 난수생성 완료
		
		for(int i=1; i<10; i++) {
			System.out.println(a*i);
		}
	}
}
