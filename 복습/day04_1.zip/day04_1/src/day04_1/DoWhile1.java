package day04_1;

import java.util.Scanner;

public class DoWhile1 {
	public static void main(String[] args) {
		
		int 주문금액	= 0;
		
		Scanner scan = new Scanner(System.in);
		
		do {
			System.out.println("할인 혜택을 받았습니다.");
			System.out.println("다음 구매금액은?");
		주문금액 = scan.nextInt();
		}while(주문금액>=15000);
		
		scan.close();
		
	}
}
