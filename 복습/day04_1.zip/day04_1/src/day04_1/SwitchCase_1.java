package day04_1;

import java.util.Scanner;

public class SwitchCase_1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("직급을 입력하세요.");
		System.out.println("[사원, 대리, 과장, 차장, 부장]");

		String rank = scan.next();
		
		switch(rank) {
			case "사원" : 
				System.out.println("사원 직급의 급여는 300만원입니다.");
				break;
			case "대리":
				System.out.println("대리 직급의 급여는 400만원입니다.");
				break;
			case "과장":
				System.out.println("과장 직급의 급여는 700만원입니다.");
				break;
			default : 
				System.out.println("잘못 입력하셨습니다.");
		}
		
	}

}
