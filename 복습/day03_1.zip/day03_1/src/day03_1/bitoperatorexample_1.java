package day03_1;

public class bitoperatorexample_1 {

	public static void main(String[] args) {
		byte a=4;
		byte b=7;
		
		System.out.println(a&b);
		System.out.println(a|b);
		System.out.println(a^b);
	}

}
