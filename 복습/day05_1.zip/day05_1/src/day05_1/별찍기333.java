package day05_1;

public class 별찍기333 {

	public static void main(String[] args) {
		
		for (int i=0; i<5; i++) {
			for (int j=0; j<3; j++) {
				System.out.print("*");
			}
			System.out.println();
			}
	}

}
