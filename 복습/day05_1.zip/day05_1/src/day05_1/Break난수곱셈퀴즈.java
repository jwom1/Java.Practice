package day05_1;

import java.util.Scanner;

public class Break난수곱셈퀴즈 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		int answer= -1;
		
		int leftNum = (int)(Math.random()*10)+1;
		int rightNum = (int)(Math.random()*10)+1;
		
		while(true) {
			System.out.println(leftNum+ "*" +rightNum +"의 정답은?");
			answer = scan.nextInt();
			if(leftNum*rightNum == answer) {
				System.out.println("정답입니다.");
			break;
			}else{
				System.out.println("오답입니다. 다시 입력해주세요.");
			}
		}
	}
}
